package com.example.football_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FootballSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
